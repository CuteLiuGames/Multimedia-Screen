如要需要更改輪播內容，請在以下資料夾或檔案更改內容：

圖片: 將以下格式的圖片
.psd、.tiff、.jpg、.tga、.png、.gif、.bmp、.iff、.picts
放入資料夾：Multimedia Screen_Data/Images

影片: 將以下格式的影片：
.asf、.avi、.dv、.m4v、.mov、.mp4、.mpg、.mpeg、.ogv、.vp8、.webm、.wmv
放入資料夾：Multimedia Screen_Data/Videos

跑馬燈: 開啟並修改此檔案：Multimedia Screen_Data/Text/TextData.txt
(跑馬燈顯示方式為一行一個內容。)

注意：更改完畢後需要重新啟動程式才會套用變更！

If you need to change the contents, please change the content in the following folder or file:

Image: Put images with the following format:
.psd, .tiff, .jpg, .tga, .png, .gif, .bmp, .iff, .picts
to this folder: Multimedia Screen_Data/Images

Videos: Put videos with the following format:
.asf, .avi, .dv, .m4v, .mov, .mp4, .mpg, .mpeg, .ogv, .vp8, .webm, .wmv
to this folder: Multimedia Screen_Data/Videos

Scrolling Text: Open and modify this file: Multimedia Screen_Data/Text/TextData.txt
(The display mode of the scrolling text is one information per line.)

Note: After making changes, you need to restart the program to apply the changes!